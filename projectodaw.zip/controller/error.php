<?php
//controller/error.php
$mensaje = "¡Ha ocurrido un error!";

require_once 'view/error.php';
?>