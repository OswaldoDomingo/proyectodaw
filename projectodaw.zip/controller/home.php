<?php
// controller/home.php

$mensaje = "Bienvenido a la página de inicio";

// Cargar la vista
require 'view/home.php';
?>