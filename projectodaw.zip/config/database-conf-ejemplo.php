<?php
$host = 'localhost';
$db   = 'evaluable_7w';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

?>