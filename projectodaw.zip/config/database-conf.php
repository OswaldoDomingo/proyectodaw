<?php
    $host = 'localhost';
    $db   = 'evaluable_7w';
    $user = 'root';
    $pass = 'kali';
    $charset = 'utf8mb4';
    
?>
