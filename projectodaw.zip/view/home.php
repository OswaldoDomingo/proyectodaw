<!DOCTYPE html>
<html lang="es">
<head>
    <!-- view/home.php -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<body>
    <h1><?php echo $mensaje ?></h1>
    <a href="index.php?page=login">Iniciar Sesión</a>
</body>
</html>